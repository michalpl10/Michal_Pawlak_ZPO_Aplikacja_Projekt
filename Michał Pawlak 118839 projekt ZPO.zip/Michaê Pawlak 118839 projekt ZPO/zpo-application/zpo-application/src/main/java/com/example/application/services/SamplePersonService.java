package com.example.application.services;

import com.example.application.data.SamplePerson;
import com.example.application.data.SamplePersonRepository;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

@Service // Adnotacja @Service wskazuje, że klasa jest serwisem Springa
public class SamplePersonService {

    private final SamplePersonRepository repository; // Pole prywatne przechowujące referencję do SamplePersonRepository.

    public SamplePersonService(SamplePersonRepository repository) {
        this.repository = repository;
    }// Konstruktor klasy SamplePersonService, który przyjmuje SamplePersonRepository jako argument i inicjalizuje pole repository.

    public Optional<SamplePerson> get(Long id) {
        return repository.findById(id);
    } // Metoda zwracająca Optional zawierający SamplePerson na podstawie podanego identyfikatora.

    public SamplePerson update(SamplePerson entity) {
        return repository.save(entity);
    } // Metoda aktualizująca encję SamplePerson w repozytorium.

    public void delete(Long id) {
        repository.deleteById(id);
    } // Metoda usuwająca encję SamplePerson na podstawie podanego identyfikatora.

    public Page<SamplePerson> list(Pageable pageable) {
        return repository.findAll(pageable);
    } //  Po wywołaniu tej metody, zwracany jest wynik zawierający kolekcję obiektów SamplePerson ograniczoną do określonej strony i posortowaną według kryteriów zdefiniowanych w Pageable

    public Page<SamplePerson> list(Pageable pageable, Specification<SamplePerson> filter) {
        return repository.findAll(filter, pageable);
    }

    public int count() {
        return (int) repository.count();
    }
}



