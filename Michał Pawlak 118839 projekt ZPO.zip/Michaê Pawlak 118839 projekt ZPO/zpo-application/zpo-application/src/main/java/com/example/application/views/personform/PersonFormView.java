package com.example.application.views.personform;

import com.example.application.data.SamplePerson;
import com.example.application.data.SamplePersonRepository;
import com.example.application.views.MainLayout;
import com.example.application.views.employees.EmployeesView;
import com.vaadin.flow.component.Composite;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.dependency.Uses;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.html.H3;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.orderedlayout.FlexComponent.Alignment;
import com.vaadin.flow.component.orderedlayout.FlexComponent.JustifyContentMode;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.EmailField;
import com.vaadin.flow.component.textfield.IntegerField;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.binder.BeanValidationBinder;
import com.vaadin.flow.data.binder.ValidationException;
import com.vaadin.flow.router.*;
import com.vaadin.flow.theme.lumo.LumoUtility.Gap;
import org.springframework.beans.factory.annotation.Autowired;

@PageTitle("Person Form") // Adnotacja używana w Vaadin do ustawienia tytułu strony dla danego widoku.
@Route(value = "person-form", layout = MainLayout.class) // Adnotacja, która określa trasę (URL) do tego konkretnego widoku
@Uses(Icon.class) // Adnotacja wskazuje na to, że ten widok może korzystać z komponentów lub funkcji związanych z klasą Icon.
public class PersonFormView extends VerticalLayout implements HasUrlParameter<String> {

    @Autowired
    private SamplePersonRepository samplePersonRepository;
    // Oznacza pole samplePersonRepository jako wstrzyknięcie zależności poprzez Spring Framework. Repozytorium to  interfejs, który obsługuje operacje bazodanowe dla encji SamplePerson.

    // Pola do wprowadzania danych
    private TextField firstName = new TextField("First Name");
    private TextField lastName = new TextField("Last Name");
    private DatePicker dateOfBirth = new DatePicker ("Birthday");
    private TextField phone = new TextField("Phone Number");
    private TextField email = new TextField("Email");
    private TextField occupation = new TextField("Occupation");
    private TextField role = new TextField("Role");
    private final Button save = new Button("Zapisz");

    private final BeanValidationBinder<SamplePerson> binder;
    // Inicjalizacja obiektu binder, który umożliwia powiązanie pól formularza z polami obiektu SamplePerson. To narzędzie Vaadin umożliwia sprawdzanie i walidację danych wprowadzanych przez użytkownika w formularzu.
    private SamplePerson samplePerson; // Pole przechowujące aktualnie edytowany obiekt SamplePerson w formularzu. Jest wykorzystywane do odczytu danych z formularza i zapisu ich do repozytorium.


    public PersonFormView() {
        FormLayout formLayout = new FormLayout(); // Tworzymy nowy układ formularza (FormLayout), który posłuży do ułożenia pól wprowadzania danych dla SamplePerson.
        formLayout.add(firstName, lastName, dateOfBirth, phone,email,occupation,role);// Dodanie pola do FormLayout.
        add(formLayout); // Dodajemy FormLayout (czyli cały formularz) do głównego VerticalLayout reprezentującego ten widok.
        add(save);
        binder = new BeanValidationBinder<>(SamplePerson.class); // Inicjalizacja obiektu binder typu BeanValidationBinder dla klasy SamplePerson, który będzie używany do wiązania pól formularza z polami obiektu SamplePerson.
        binder.bindInstanceFields(this); // Wiązanie pól instancji klasy PersonFormView z odpowiadającymi im polami obiektu SamplePerson za pomocą binder.
        save.addClickListener(e->{
            try{
                if(this.samplePerson == null){ //  Sprawdzamy, czy samplePerson jest null. Jeśli tak, tworzy nowy obiekt SamplePerson.
                    this.samplePerson = new SamplePerson();
                }
                binder.writeBean(this.samplePerson); // Przepisujemy dane z pól formularza do obiektu samplePerson.
                samplePersonRepository.save(samplePerson); //  Zapisanie danych do repozytorium
                UI.getCurrent().navigate(EmployeesView.class); //  Po udanym zapisie, następuje nawigacja do widoku EmployeesView
            }catch(ValidationException ex) { // Wyjątek błędu walidacji
                ex.printStackTrace();
            }
        });
    }

    @Override
    public void setParameter(BeforeEvent beforeEvent, @OptionalParameter String personId) {
        //Ta metoda jest wywoływana, gdy widok otrzymuje parametry z adresu URL. Przyjmuje dwa argumenty: beforeEvent reprezentujący zdarzenie przed nawigacją do widoku oraz opcjonalny parametr personId - identyfikator osoby przekazywany w adresie URL.
        if(personId != null){
            samplePersonRepository.findById(Long.valueOf(personId)).ifPresent(samplePerson ->{
                this.samplePerson = samplePerson;
                binder.readBean(this.samplePerson);
                // Wykorzystujemy samplePersonRepository do wyszukania osoby o określonym personId. Jeśli osoba o takim ID istnieje, to zostaje przekazana do bloku ifPresent, gdzie następuje przypisanie znalezionej
                // osoby do zmiennej this.samplePerson, a następnie dane z tej osoby są odczytywane do formularza za pomocą binder.readBean(this.samplePerson);.
            });
        }
    }//Adres id obiektu w url
}

