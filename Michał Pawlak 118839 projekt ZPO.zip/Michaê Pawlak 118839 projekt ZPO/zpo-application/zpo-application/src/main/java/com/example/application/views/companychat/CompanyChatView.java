package com.example.application.views.companychat;
import com.example.application.views.MainLayout;
import com.vaadin.collaborationengine.CollaborationAvatarGroup;
import com.vaadin.collaborationengine.CollaborationMessageInput;
import com.vaadin.collaborationengine.CollaborationMessageList;
import com.vaadin.collaborationengine.UserInfo;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.Key;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.router.RouteAlias;
@PageTitle("Company Chat") // Ta adnotacja określa tytuł strony, który będzie wyświetlany w przeglądarce dla widoku oznaczonego tą adnotacją.
@Route(value = "company-chat", layout = MainLayout.class) //  Adnotacja @Route definiuje adres URL, pod którym będzie dostępny dany widok.
@RouteAlias(value = "", layout = MainLayout.class) // To alias dla ścieżki pustej, co oznacza stronę główną aplikacji.
public class CompanyChatView extends HorizontalLayout {
    private UserInfo userInfo; // Zmienna typu UserInfo, która przechowuje informacje o użytkowniku czatu.
    private final Button refresh = new Button("Refresh");

    public CompanyChatView() { //Ten konstruktor jest wywoływany, gdy tworzona jest nowa instancja CompanyChatView.
        Component enterLayout = createEnterLayout(); //Tworzymy nową zmienną lokalną enterLayout i inicjalizujemy ją za pomocą wyniku metody createEnterLayout(). Ta metoda jest odpowiedzialna za stworzenie layoutu służącego do logowania użytkownika.
        add(enterLayout); //  Dodajemy enterLayout do bieżącego CompanyChatView. To oznacza, że layout stworzony w metodzie createEnterLayout() będzie zawartością CompanyChatView.
    }
    public Component createEnterLayout(){
        VerticalLayout enterLayout = new VerticalLayout(); // Tworzymy nowy pionowy układ VerticalLayout, który będzie kontenerem dla elementów logowania.
        TextField name = new TextField("Your login");; // Pole tekstowe o etykiecie "Your login", które będzie służyć do wprowadzenia nazwy użytkownika.
        Button login = new Button("Say Hello!");; // Przycisk o tekście "Say Hello!", który będzie służył do zalogowania.
        login.addClickListener(e -> {
            String userFullName = name.getValue(); // Pobieranie wartości wpisanej w polu tekstowym i przypisanie jej do zmiennej userFullName.
            String userName = userFullName.replaceAll("\\s+","").toLowerCase(); // Czyszczenie wprowadzonej nazwy użytkownika - usuwa białe znaki i zmienia wszystkie litery na małe, a następnie przypisuje tę zmienioną nazwę do zmiennej userName.
            userInfo = new UserInfo(userName, userFullName); // Obiekt UserInfo z danymi użytkownika: nazwą użytkownika i pełnym imieniem użytkownika.
            Component chatLayout = createChatLayout(); // Tworzymy interfejs użytkownika czatu firmy poprzez wywołanie metody createChatLayout().
            CompanyChatView.this.replace(enterLayout,chatLayout); //Zamieniamy interfejs logowania (enterLayout) na interfejs czatu firmy (chatLayout) w bieżącym widoku CompanyChatView.
        });
        enterLayout.add(name, login); // Dodajemy pole tekstowe i przycisk do interfejsu logowania.
        return enterLayout; // Zwracamy stworzony interfejs logowania, który będzie wyświetlany w aplikacji.
    }
    public Component createChatLayout(){ // Metoda tworząca interfejs użytkownika służący do rozmów w czacie.

        CollaborationMessageList list = new CollaborationMessageList(userInfo, "chat"); // Tworzymy listę wiadomości z przypisanym użytkownikiem oraz identyfikatorem czatu ("chat"). Ta lista przechowuje i wyświetla wiadomości w interfejsie czatu.
        CollaborationMessageInput input = new CollaborationMessageInput(list); // Pole do wprowadzania wiadomości powiązane z listą wiadomości (list). To pole pozwala użytkownikowi wprowadzać nowe wiadomości do czatu.
        VerticalLayout layout = new VerticalLayout(); // TPionowy układ, który będzie kontenerem dla elementów interfejsu czatu.
        layout.add(refresh); // Dodajemy przycisk "Refresh" do układu czatu.
        refresh.addClickListener(e -> { // Dodanie słuchacza zdarzeń do przycisku "Refresh". Kiedy przycisk zostanie kliknięty, czat zostanie odświeżony
            getUI().ifPresent(ui -> ui.getPage().reload());
        });

        CollaborationAvatarGroup avatars = new CollaborationAvatarGroup(userInfo, "chat"); // Tworzymy grupę awatarów powiązaną z użytkownikiemoraz identyfikatorem czatu.
        list.setSizeFull(); // Ustawiamy pełny rozmiar dla listy wiadomości, co sprawi, że zajmie ona całą dostępną przestrzeń w układzie.
        input.setWidthFull(); // Ustawiamy pełną szerokość dla pola do wprowadzania wiadomości,
        layout.add(avatars,list,input); //  Dodajemy do układu kolejno: grupę awatarów, listę wiadomości i pole do wprowadzania wiadomości.
        layout.expand(list); //  Rozszerza listę wiadomości, aby zajęła jak najwięcej dostępnego miejsca w układzie.
        layout.setSizeFull(); // Ustawia pełny rozmiar dla układu czatu, co sprawi, że zajmie on całą dostępną przestrzeń.
        return layout; // Zwracamy stworzony interfejs czatu, który będzie wyświetlany w aplikacji.
    }
}


