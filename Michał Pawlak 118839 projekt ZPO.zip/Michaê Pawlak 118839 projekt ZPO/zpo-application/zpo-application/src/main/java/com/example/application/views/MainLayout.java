package com.example.application.views;
import com.example.application.views.companychat.CompanyChatView;
import com.example.application.views.employees.EmployeesView;
import com.example.application.views.personform.PersonFormView;
import com.vaadin.flow.component.applayout.AppLayout;
import com.vaadin.flow.component.applayout.DrawerToggle;
import com.vaadin.flow.component.html.Footer;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.html.Header;
import com.vaadin.flow.component.orderedlayout.Scroller;
import com.vaadin.flow.component.sidenav.SideNav;
import com.vaadin.flow.component.sidenav.SideNavItem;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.theme.lumo.LumoUtility;
import org.vaadin.lineawesome.LineAwesomeIcon;
public class MainLayout extends AppLayout { // Klasa MainLayout rozszerza AppLayout, co oznacza, że jest to komponent reprezentujący szablon strony aplikacji z narzędziami do organizacji treści.
    private H2 viewTitle; // pole viewTitle przechowuje nagłówek stron

    public MainLayout() {
        setPrimarySection(Section.DRAWER); // Ustawienie głównej sekcji aplikacji na DRAWER, co oznacza, że boczne menu (Drawer) będzie główną sekcją, która jest widoczna lub aktywna w układzie aplikacji.
        addDrawerContent(); // Dodanie zawartości do bocznego menu (Drawer) w aplikacji.
        addHeaderContent(); // Dodanie zawartości do nagłówka (Header) aplikacji.
    }

    private void addHeaderContent() {
        DrawerToggle toggle = new DrawerToggle(); // Stworzenie obiektu DrawerToggle. Jest to przycisk, który pozwala na otwarcie i zamknięcie bocznego menu (Drawer).
        viewTitle = new H2(); // Tytuł aktualnie wyświetlanego widoku. Jest to element nagłówka, który może być dynamicznie aktualizowany w zależności od bieżącego widoku w aplikacji.
        addToNavbar(true, toggle, viewTitle); //Dodanie elementów do paska nawigacyjnego (navbar).
    }

    private void addDrawerContent() {
        H1 appName = new H1("ZPO-Application"); // Tworzymy obiekt H1 o nazwie appName, który zawiera nazwę apliacji, która będzie wyświetlana w bocznym menu.
        appName.addClassNames(LumoUtility.FontSize.LARGE, LumoUtility.Margin.NONE); // Nadajemy odpowiedni rozmiar i styl marginesu dla tego nagłówka aplikacji.
        Header header = new Header(appName); // Obiekt header jest komponentem Vaadin, który może być używany do grupowania innych komponentów w kontekście nagłówka.
        Scroller scroller = new Scroller(createNavigation()); // Tworzymy obiekt Scroller, który jest kontenerem do przewijania zawartości.
        // Jako zawartość przewijaną wykorzystuje wynik metody createNavigation(), która tworzy menu nawigacyjne (SideNav) z różnymi elementami.
        addToDrawer(header, scroller); // Mtoda Vaadina, która umieszcza elementy w bocznym menu aplikacji.
    }
    private SideNav createNavigation() {
        // Metoda tworzy i zwraca boczne menu nawigacyjne, zawierające elementy nawigacyjne reprezentujące różne widoki w aplikacji, z ich nazwami, klasami powiązanymi z widokami i odpowiadającymi im ikonami
        SideNav nav = new SideNav(); //Tworzymy obiekt SideNav, czyli boczne menu nawigacyjne.
        nav.addItem(new SideNavItem("Company Chat", CompanyChatView.class, LineAwesomeIcon.GLOBE_SOLID.create()));
        nav.addItem(new SideNavItem("Person Form", PersonFormView.class, LineAwesomeIcon.USER.create()));
        nav.addItem(new SideNavItem("Employees", EmployeesView.class, LineAwesomeIcon.COLUMNS_SOLID.create()));
        return nav;
    }
    @Override
    protected void afterNavigation() {
        super.afterNavigation(); // Wywołuje metodę afterNavigation() z klasy nadrzędnej, która może wykonywać pewne operacje w kontekście nawigacji.
        viewTitle.setText(getCurrentPageTitle()); //Ustawia tekst dla pola viewTitle, który  reprezentuje tytuł aktualnego widoku. Wykorzystuje metodę getCurrentPageTitle(), która zwraca tytuł bieżącej strony.
    }

    private String getCurrentPageTitle() {
        PageTitle title = getContent().getClass().getAnnotation(PageTitle.class); // getContent() zwraca zawartość  aktualnie wyświetlanego widoku. Metoda getClass() zwraca klasę odpowiadającą tej zawartości. getAnnotation() próbuje pobrać adnotację @PageTitle przypisaną do tej klasy.
        return title == null ? "" : title.value(); // Sprawdzamy, czy adnotacja @PageTitle została znaleziona dla aktualnego widoku.
                                                  // Jeśli title jest null, zwraca pusty ciąg znaków "".
                                                //Jeśli title nie jest null, zwraca wartość (value) tej adnotacji, czyli właśnie tytuł bieżącej strony.
    }
}
