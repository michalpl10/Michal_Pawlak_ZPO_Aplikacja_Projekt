package com.example.application.views.employees;

import com.example.application.data.SamplePerson;
import com.example.application.data.SamplePersonRepository;
import com.example.application.services.SamplePersonService;
import com.example.application.views.MainLayout;
import com.example.application.views.personform.PersonFormView;
import com.vaadin.flow.component.AttachEvent;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.dependency.Uses;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.grid.Grid;

import com.vaadin.flow.component.grid.GridVariant;
import com.vaadin.flow.component.icon.Icon;

import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;

import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.spring.data.VaadinSpringDataHelpers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.orm.ObjectOptimisticLockingFailureException;

@PageTitle("Employees")
@Route(value = "employees", layout = MainLayout.class)
@Uses(Icon.class)
public class EmployeesView extends VerticalLayout {
    @Autowired
    private SamplePersonRepository samplePersonRepository;
    private Button addButton = new Button("Dodaj");
    private Button editButton = new Button("Edytuj");
    private Button deleteButton = new Button("Usuń");
    private Button detailsButton = new Button("Szczegóły ");


    private Grid<SamplePerson> grid = new Grid<>(SamplePerson.class);

    public EmployeesView(SamplePersonService samplePersonService) {
        setSizeFull();
        add(new HorizontalLayout(addButton, editButton, deleteButton, detailsButton)); //dodanie przycisków
        grid.setColumns(
                "firstName",
                "lastName",
                "dateOfBirth",
                "email",
                "phone",
                "occupation",
                "role"
        );
        add(grid);

        //--------------------------------------------------------------
        //Przyciski edycji, usunięcia i szczegółów aktywują się w momencie kiedy wybierzemy jakiegoś pracownika
        editButton.setEnabled(false);
        deleteButton.setEnabled(false);
        detailsButton.setEnabled(false);
        grid.asSingleSelect().addValueChangeListener(e -> { //Sluchacz zdarzenia zaznaczenia czegoś w gridzie
            if (e.getValue() != null) {
                editButton.setEnabled(true);
                deleteButton.setEnabled(true);
                detailsButton.setEnabled(true);
            } else {
                editButton.setEnabled(false);
                deleteButton.setEnabled(false);
                detailsButton.setEnabled(false);
            }
        });
        //------------------------------------------------------------

        //--------------------------------------------------------------------------------------
        // Po kliknięciu przycisku zostaniemy przeniesieni na inną stronę
        addButton.addClickListener(e -> {
            getUI().ifPresent(ui -> ui.navigate(PersonFormView.class)//Nawigacja na daną stronę
            );
        });

        editButton.addClickListener(e -> {
            SamplePerson selected = grid.asSingleSelect().getValue();
            UI.getCurrent().navigate(PersonFormView.class, selected.getId().toString());
        });

        deleteButton.addClickListener(e -> {
            SamplePerson selected = grid.asSingleSelect().getValue();
            samplePersonRepository.delete(selected);
            refresh();
        });

        detailsButton.addClickListener(e -> {
            SamplePerson selected = grid.asSingleSelect().getValue();
            UI.getCurrent().navigate(PersonFormView.class, selected.getId().toString());

        });
        //-------------------------------------------------------------------------------
    }
    @Override
    protected void onAttach(AttachEvent attachEvent) { //Odświeżenie zawartośći tabeli kiedy wejdzie się na widok
         refresh();
    }

    private void refresh(){
        List<SamplePerson> data = samplePersonRepository.findAll();
        grid.setItems(data);
    }
}



