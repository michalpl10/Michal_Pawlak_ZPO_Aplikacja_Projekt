import { N as e, L as o } from "./copilot-tF9CaZ8e.js";
const a = {
  tagName: "vaadin-icon",
  displayName: "Icon",
  elements: [
    {
      selector: "vaadin-icon",
      displayName: "Icon",
      properties: [
        e.iconColor,
        e.iconSize,
        o.backgroundColor,
        o.borderColor,
        o.borderWidth,
        o.borderRadius
      ]
    }
  ]
};
export {
  a as default
};
