import { Q as a } from "./copilot-tF9CaZ8e.js";
const t = {
  tagName: "vaadin-details",
  displayName: "Details",
  elements: [
    {
      selector: "vaadin-details",
      displayName: "Root element",
      properties: a
    }
  ]
};
export {
  t as default
};
