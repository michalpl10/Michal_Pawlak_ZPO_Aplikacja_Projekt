import { L as r } from "./copilot-tF9CaZ8e.js";
const e = {
  tagName: "vaadin-progress-bar",
  displayName: "Progress Bar",
  elements: [
    {
      selector: "vaadin-progress-bar::part(bar)",
      displayName: "Bar",
      properties: [r.backgroundColor]
    },
    {
      selector: "vaadin-progress-bar::part(value)",
      displayName: "Value",
      properties: [r.backgroundColor]
    }
  ]
};
export {
  e as default
};
