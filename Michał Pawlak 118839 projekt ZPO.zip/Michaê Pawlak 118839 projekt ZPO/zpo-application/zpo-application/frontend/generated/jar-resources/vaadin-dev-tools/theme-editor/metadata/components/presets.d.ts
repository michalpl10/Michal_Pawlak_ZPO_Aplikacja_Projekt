export declare const presets: {
    lumoSize: string[];
    lumoSpace: string[];
    lumoBorderRadius: string[];
    lumoFontSize: string[];
    lumoTextColor: string[];
    basicBorderSize: string[];
};
