import {applyTheme as _applyTheme} from './theme-zpo-application.generated.js';
export const applyTheme = _applyTheme;
